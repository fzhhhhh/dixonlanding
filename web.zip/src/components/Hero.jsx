import { Container, Row, Col, Button, Badge } from "react-bootstrap";
import heroImg from "../assets/hero.jpg";

function Hero() {
  return (
    <section id="inicio" className="hero-section">
      <Container>
        <Row className="align-items-center min-vh-100 py-5 g-5">
          <Col lg={6}>
            <Badge className="hero-badge mb-3">
              Taller especializado en motocicletas
            </Badge>

            <h1 className="hero-title">
              Mantenimiento, diagnóstico y reparación para que tu moto rinda al máximo
            </h1>

            <p className="hero-text">
              Servicio profesional para motos de calle, trabajo y alta cilindrada.
              Hacemos mecánica general, frenos, transmisión, electricidad y service completo.
            </p>

            <div className="d-flex flex-wrap gap-3 mt-4">
              <Button className="btn-hero-primary" href="#contacto">
                Pedir presupuesto
              </Button>

              <Button className="btn-hero-secondary" href="#servicios">
                Ver servicios
              </Button>
            </div>

            <div className="hero-stats mt-5">
              <div className="hero-stat-item">
                <h3>+500</h3>
                <p>Motos atendidas</p>
              </div>

              <div className="hero-stat-item">
                <h3>+8</h3>
                <p>Años de experiencia</p>
              </div>

              <div className="hero-stat-item">
                <h3>100%</h3>
                <p>Atención personalizada</p>
              </div>
            </div>
          </Col>

          <Col lg={6} className="mt-4 mt-lg-0">
            <div className="hero-image-card">
              <img
                src={heroImg}
                alt="Moto en taller"
                className="hero-image"
              />
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
}

export default Hero;