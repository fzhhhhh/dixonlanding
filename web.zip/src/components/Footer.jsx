import { Container } from "react-bootstrap";

function Footer() {
  return (
    <footer className="footer-taller py-4">
      <Container className="text-center">
        <p className="mb-0">© 2026 Dixon Moto Garaje - Taller de motocicletas. </p>
      </Container>
    </footer>
  );
}

export default Footer;